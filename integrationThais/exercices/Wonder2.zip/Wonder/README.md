# ![Wonder](img/page-logo.png)

## Consigne

Intégrez ce site en ignorant la compatibilité avec les anciens navigateurs (<
IE10).

Utilisez des flexbox pour remplacer le float (cf.  [liens](LINKS.md)). Vous aurez
besoin de comprendre le principe des *sprites* CSS.

Vous pouvez utiliser l’unité « REM » sans vous soucier du *fallback* en pixel.

Rendez-vous sur [html5boilerplate](http://html5boilerplate.com/). Utilisez la
base de travail fournie pour commencer votre exercice. Prenez bien soin de
configurer boilerplate à votre goût.


Pour les diaporama, utilisez au choix une des librairies javascript :

- [Bxslider](http://bxslider.com/)
- [Flexslider](http://www.woothemes.com/flexslider/)