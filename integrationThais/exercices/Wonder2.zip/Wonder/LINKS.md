# Liens utiles

- [Flexbox](http://css-tricks.com/snippets/css/a-guide-to-flexbox/)
- [Les sprites CSS](http://fr.openclassrooms.com/informatique/cours/bien-utiliser-les-sprites-css)
- [Compatibilité Flexbox](http://caniuse.com/#feat=flexbox)
- [Boilerplate](http://html5boilerplate.com)
- [Flexslider](http://www.woothemes.com/flexslider/)
- [Bxslider](http://bxslider.com/)
- [Google font](https://www.google.com/fonts)
- [Unité REM](http://pleeease.io/)


# Aller plus loin

- [Fonction calc CSS](https://developer.mozilla.org/en-US/docs/Web/CSS/calc)
- [Requirejs +++](http://requirejs.org/)
- [Post-processeur CSS Pleeease +](http://pleeease.io/)
