$(function() {

var li;



$.ajax ({
	method: "GET",
	url: "ajax.php?jefais=affiche",
	success: function(elem) {

		var ul = $("body").append($("<ul>"));

		for (var i=0; i<elem.length; i++) {

			li = $("<li>");
			li.text(elem[i].pseudo + " : " + elem[i].message +
				 "<br />date : " + elem[i].date + "<br /><br />");
			ul.append(li);		
		}

	}
});




$(".btnPublier").on("click", function() {

	$.ajax ({
		method: "POST",
		url: "ajax.php?jefais=enreg",
		data: {
			pseudo: $("input[name='pseudo']").val(),
			message: $("textarea[name='message']").val()
		},
		success: function() {


		}



	});
	return false;
}); /* fin "btnPublier").on("click", */




});