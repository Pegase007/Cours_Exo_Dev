# Consigne, partie 3

## Partie 1
Intégrez le formulaire de la maquette dans une page à part, en utilisant le
layout créé dans l’exercice *Typography*.

## Partie 2
Intégrez le tableau de la maquette dans une page à part, en utilisant le
layout créé dans l’exercice *Typography*.
