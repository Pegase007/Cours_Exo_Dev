<?php 
header("content-type: application/json");

$bdd = new PDO("mysql:host=localhost;dbname=devdoc", "08saronce", "mdp");
/*
	deux tables : 
		dossiers : id,  name
		fichiers : id,  dossier,  name
*/

$req = $bdd -> prepare("SELECT *, f.name AS filename, d.name AS dirname, d.1 AS idDuDossier FROM dossiers d INNER JOIN fichiers f ON d.1 = f.dossier_id ");
$req -> execute();

$liste_dossiers = $req -> fetchAll(PDO::FETCH_ASSOC);

echo json_encode($liste_dossiers);
?>
